# Fitbit Air Posture Lab v0.2.0

Android field-test app for a back-mounted Google Fitbit Air posture experiment.

## What this build does

- Scans for a nearby Fitbit Air over BLE.
- Connects and inventories GATT services/characteristics.
- Subscribes to NOTIFY/INDICATE characteristics by writing only the standard CCCD.
- Records scan advertisements, RSSI, connection state, MTU, service inventory, and notification payload bytes.
- Adds high-precision timestamps (`utc_ms`, `elapsed_ns`) to every event.
- Lets the tester add motion correlation markers: neutral posture, forward/slouch posture, walking, and an official Fitbit-side alarm event.
- Exports the current diagnostic session as one ZIP via the Android share sheet.
- Hashes Bluetooth MAC addresses with a per-session salt before they enter the diagnostic log.
- Provides a double-pulse Android phone vibration test.
- Includes the posture engine developed in v0.1 (12° enter / 8° exit hysteresis, 4 s dwell, 30 s repeat) ready to connect once the Air IMU packet format is identified.

## Recommended capture procedure

1. Install the APK and grant Nearby devices / Bluetooth permission.
2. Wear the Fitbit Air firmly on the upper back so it cannot rotate relative to your torso.
3. Tap `Fitbit AirをBLEスキャン・解析`.
4. When connected, keep still for 10 seconds and tap `マーカー: 直立/良い姿勢` at the beginning.
5. Slouch/lean forward and hold for 10 seconds; tap `マーカー: 前傾/悪い姿勢` at the beginning.
6. Walk or move normally for 15-30 seconds; tap `マーカー: 歩行・日常動作` at the beginning.
7. If possible, trigger an official Fitbit silent alarm and tap `マーカー: Fitbit側アラームを今作動` immediately before/when it vibrates. This is useful for identifying the haptic path without guessing proprietary commands.
8. Tap `ログZIPを共有 / ChatGPTへ送る` and upload the ZIP to ChatGPT.

The next analysis can correlate packet timing/entropy/deltas with the motion markers, identify likely IMU-bearing characteristics, infer sample framing/endian/scales, and then wire a verified decoder into `PostureEngine`.

## Safety / scope

The app does not attempt firmware modification, pairing bypass, credential extraction, or arbitrary proprietary writes. The probe's only write is the standard Client Characteristic Configuration Descriptor used to request notifications. Fitbit-specific vibration commands remain disabled until a verified protocol path is identified on a device the tester owns.

## Build

- AGP 9.3.0
- Kotlin 2.3.21
- compileSdk / targetSdk 37
- minSdk 31
